﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Plan1.Models
{
    public class DHBlob
    {
        public string blobURI { get; set; }

        public string blobContainer { get; set; }

        public string blobRef { get; set; }
    }
}